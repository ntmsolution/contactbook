package com.example.my_cntcbook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.my_cntcbook.DB.DBmain;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    FloatingActionButton fb;
    ListView lv;
    DBmain objdb ;
    ArrayList<ContentValues> ar;
    ImageView profileimg;
    Context c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fb = findViewById(R.id.fb);
        c = MainActivity.this;
        lv = findViewById(R.id.lv);



        objdb = new DBmain(c);




        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(MainActivity.this,AddContact.class);
                startActivity(i);
            }
        });

        displaydata();


    }

    class Custom extends BaseAdapter {
        @Override
        public int getCount() {
            return ar.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View v, ViewGroup ViewGroup) {

            v = LayoutInflater.from(c).inflate(R.layout.secondpage_data,ViewGroup,false);
           ImageView profile_image =v.findViewById(R.id.profile_image);
            TextView tvname = v.findViewById(R.id.tvname);
            TextView tvpath = v.findViewById(R.id.tvpath);
            final ContentValues cv = ar.get(i);
            tvname.setText(cv.getAsString("fname"));
            tvpath.setText(cv.getAsString("tvmsg"));
           //profile_image.setImageURI(Uri.parse("tvmsg"));
            if(!cv.getAsString("tvmsg").isEmpty()) {
                profile_image.setImageURI(Uri.parse(cv.getAsString("tvmsg")));
            }

            tvname.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SQLiteDatabase db = objdb.getReadableDatabase();
                    Cursor cursor = db.rawQuery("select * from user where id="+cv.getAsInteger("id"),null);
                    cursor.moveToFirst();

                    Bundle bundle = new Bundle();
                    bundle.putInt("id",cursor.getInt(0));
                    bundle.putString("fname",cursor.getString(3));
                    bundle.putString("lname",cursor.getString(4));
                    bundle.putString("number1",cursor.getString(1));
                    bundle.putString("number2",cursor.getString(2));

                    Intent i = new Intent(MainActivity.this,thirdpage.class);
                    i.putExtra("data",bundle);
                    startActivity(i);
                }
            });
            return v;
        }
    }
    void displaydata(){
        ar = new ArrayList();
        SQLiteDatabase db = objdb.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from user",null);

        if(cursor.getCount()>0){
            while (cursor.moveToNext()){
                ContentValues cv = new ContentValues();
                cv.put("id",cursor.getInt(0));
                cv.put("fname",cursor.getString(3));
                cv.put("tvmsg",cursor.getString(5));

                ar.add(cv);


            }

            Custom adapter=new Custom();
            lv.setAdapter(adapter);



        }

    }
}




