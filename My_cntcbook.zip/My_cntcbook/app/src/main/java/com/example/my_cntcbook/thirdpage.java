package com.example.my_cntcbook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.my_cntcbook.DB.DBmain;

import java.util.ArrayList;
import java.util.ResourceBundle;

public class thirdpage extends AppCompatActivity {
    private static  final int REQUEST_CALL=1;
    Context c;
    TextView tv_fname, tv_lname, tv_num1, tv_num2;
    Button btn_delet3, btn_edit, btn_call;
    DBmain objdb;
    ImageView edit_profile;
    int id = 0;
    ArrayList<ContentValues> ar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thirdpage);

        c = thirdpage.this;
        tv_fname = findViewById(R.id.tv_fname);
        tv_lname = findViewById(R.id.tv_lname);
        tv_num1 = findViewById(R.id.tv_num1);
        tv_num2 = findViewById(R.id.tv_num2);
        edit_profile = findViewById(R.id.edit_profile);

        btn_delet3 = findViewById(R.id.btn_delete3);
        btn_edit = findViewById(R.id.btn_edit);
        btn_call = findViewById(R.id.btn_call);

        objdb = new DBmain(c);


        Intent i1 = getIntent();
        if (i1.getBundleExtra("data") != null) {

            final Bundle bundle = i1.getBundleExtra("data");

            id = bundle.getInt("id");
            tv_fname.setText(bundle.getString("fname"));
            tv_lname.setText(bundle.getString("lname"));
            tv_num1.setText(bundle.getString("number1"));
            tv_num2.setText(bundle.getString("number2"));
            edit_profile.setImageURI(Uri.parse("tvmsg"));


            btn_call.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    makePhoneCall();
                }
                private void makePhoneCall(){
                    String number =tv_num1.getText().toString();
                    if(number.length()>0){
                        if(ContextCompat.checkSelfPermission(c, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
                            ActivityCompat.requestPermissions(thirdpage.this,new String[]{Manifest.permission.CALL_PHONE},REQUEST_CALL);
                        }else{
                            String dial="tel:"+number;
                            startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
                        }

                    }else{
                        Toast.makeText(c,"1",Toast.LENGTH_SHORT).toString();
                    }
                }
            });
            btn_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = objdb.getReadableDatabase();
                Cursor cursor = db.rawQuery("select * from user where id="+bundle.getInt("id"),null);
                cursor.moveToFirst();

                Bundle bundle = new Bundle();
                bundle.putInt("id",cursor.getInt(0));
                bundle.putString("fname",cursor.getString(3));
                bundle.putString("lname",cursor.getString(4));
                bundle.putString("number1",cursor.getString(1));
                bundle.putString("number2",cursor.getString(2));

                Intent i = new Intent(c,AddContact.class);
                i.putExtra("data",bundle);
                startActivity(i);
          }
        });

        btn_delet3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = objdb.getWritableDatabase();
                long id = db.delete("user","id="+bundle.getInt("id"),null);

                if(id!=-1){
                    Toast.makeText(c,"Record Deleted Successfully",Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(c,MainActivity.class);
                    startActivity(i);
                }

            }
        });
            }

        }
    }




